<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Films</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
    <?php echo $__env->yieldContent('css'); ?>
  </head>
  <body>
    <main class="section">
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
  </body>
</html><?php /**PATH E:\laragon\www\laravel11\resources\views/template.blade.php ENDPATH**/ ?>