<?php if($paginator->hasPages()): ?>
    <nav class="pagination is-centered" role="navigation" aria-label="pagination">
        
        <a class="pagination-previous" <?php echo e($paginator->onFirstPage() ? "disabled" : ""); ?>

        href="<?php echo e($paginator->previousPageUrl()); ?>">
            <?php echo app('translator')->get('pagination.previous'); ?>
        </a>

        <a class="pagination-next" <?php echo e($paginator->hasMorePages() ? "" : "disabled"); ?>

        href="<?php echo e($paginator->nextPageUrl()); ?>">
            <?php echo app('translator')->get('pagination.next'); ?>
        </a>
        

        
        <ul class="pagination-list">
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li>
                        <span class="pagination-ellipsis"><?php echo e($element); ?></span>
                    </li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a class="pagination-link <?php echo e($page == $paginator->currentPage() ? "is-current" : ""); ?>"
                               href="<?php echo e($url); ?>" aria-label="Goto page <?php echo e($page); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </nav>
<?php endif; ?><?php /**PATH E:\laragon\www\laravel11\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>